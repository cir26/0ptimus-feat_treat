Feat_Treat is a package that contains a class by same name to assist python users in treating and testing data sets with machine learning models.

Users can create objects of feature sets and their labels.
Various methods are included to treat feature sets and validate machine learning models trained on these sets.
